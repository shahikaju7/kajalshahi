### Hi there, I'm [Muskan!](https://github.com/muskan272002)<img height="50px" src="https://github.com/muskan272002/muskan272002/blob/main/New/Hello.gif">

## I am an enthusiastic student 🙂


- 💻 I am an undergraduate learning Computer Science and Engineering at MNNIT, Allahabad.

- 🌱 I am looking forward to learn Python.

- 📱 I am currently working on Web Development.

- 👯 I'm looking forward to collaborate with other content creators.

- 😄 Pronouns: She/Her

- ⚡ Fun fact: I love to dance and sing.

### Contact :point_down:
&nbsp; &nbsp; <a href="https://www.linkedin.com/in/muskan-patel-8b875b205/">
    <img align="center" width="26px" src="https://github.com/muskan272002/muskan272002/blob/main/New/linkedin.jpeg" />

 
 &nbsp; &nbsp; <a href="mailto:muskanpatel272002@gmail.com">
    <img align="center" width="26px" src="https://github.com/muskan272002/muskan272002/blob/main/New/gmail.png" />


### Visitors Count :eyes:

![visitors](https://visitor-badge.glitch.me/badge?page_id=muskan272002)

<!-- <img align="left" src = "https://profile-counter.glitch.me/muskan272002/count.svg" alt ="Loading"> -->
